import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/util.dart';
import '../news/news_service.dart';
import '../telegram/telegram_service.dart';
import 'summarizer.dart';

class AiSummaryPage extends StatefulWidget {
  const AiSummaryPage({super.key});
  @override
  State<AiSummaryPage> createState() => _AiSummaryPageState();
}

class _AiSummaryPageState extends State<AiSummaryPage> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
  SumStyle _style = SumStyle.medium;
  int _hours = 24;
  String _result = '';
  List<SumItem> _hits = [];
  final _q = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    _q.dispose();
    super.dispose();
  }

  List<SumItem> _all() => [
        for (final a in newsService.articles) SumItem(a.title, stripHtml(a.content), a.category, a.feedTitle, a.published),
        for (final m in telegramService.messages) SumItem(m.text.split('\n').first, m.text, 'تلگرام', '@${m.channel}', m.time),
      ];

  void _run() {
    final since = DateTime.now().subtract(Duration(hours: _hours));
    final items = _all().where((e) => e.time.isAfter(since)).toList();
    setState(() => _result = Summarizer.summarize(items, _style));
  }

  void _search() => setState(() => _hits = Summarizer.search(_all(), _q.text));

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.primary;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.auto_fix_high, color: accent),
          Icon(Icons.auto_awesome, size: 14, color: accent),
          const SizedBox(width: 8),
          const Text('AI SUMMARY', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
        ]),
      ),
      body: AnimatedBuilder(
        animation: _c,
        builder: (context, child) => CustomPaint(painter: _StarPainter(_c.value, accent), child: child),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              SegmentedButton<SumStyle>(
                segments: const [
                  ButtonSegment(value: SumStyle.short, label: Text('کوتاه')),
                  ButtonSegment(value: SumStyle.medium, label: Text('متوسط')),
                  ButtonSegment(value: SumStyle.analytical, label: Text('تحلیلی')),
                ],
                selected: {_style},
                onSelectionChanged: (s) => setState(() => _style = s.first),
              ),
              const SizedBox(height: 10),
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 1, label: Text('ساعتی')),
                  ButtonSegment(value: 24, label: Text('روزانه')),
                  ButtonSegment(value: 168, label: Text('هفتگی')),
                ],
                selected: {_hours},
                onSelectionChanged: (s) => setState(() => _hours = s.first),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(onPressed: _run, icon: const Icon(Icons.auto_awesome), label: const Text('خلاصه کن')),
              if (_result.isNotEmpty)
                Container(
                  margin: const EdgeInsets.only(top: 14),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.07), borderRadius: BorderRadius.circular(16), border: Border.all(color: accent.withOpacity(0.4))),
                  child: SelectableText(_result, style: const TextStyle(height: 1.9, color: Colors.white)),
                ),
              const Divider(height: 36, color: Colors.white24),
              TextField(
                controller: _q,
                style: const TextStyle(color: Colors.white),
                onSubmitted: (_) => _search(),
                decoration: InputDecoration(
                  hintText: 'جست‌وجو در آرشیو ذخیره‌شده (آفلاین)',
                  hintStyle: const TextStyle(color: Colors.white54),
                  suffixIcon: IconButton(icon: const Icon(Icons.search, color: Colors.white), onPressed: _search),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
              for (final h in _hits)
                Container(
                  margin: const EdgeInsets.only(top: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(12)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(h.title, style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.white)),
                    const SizedBox(height: 4),
                    Text('${h.source} • ${timeAgo(h.time)}', style: TextStyle(fontSize: 11, color: accent)),
                  ]),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StarPainter extends CustomPainter {
  final double t;
  final Color accent;
  _StarPainter(this.t, this.accent);
  static final List<List<double>> _stars = () {
    final r = Random(7);
    return List.generate(110, (_) => [r.nextDouble(), r.nextDouble(), 0.6 + r.nextDouble() * 1.8, r.nextDouble() * 6.28]);
  }();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF05060F), Color(0xFF1A1033), Color(0xFF0A1830)]).createShader(rect),
    );
    final p = Paint();
    for (final s in _stars) {
      final tw = 0.35 + 0.65 * (0.5 + 0.5 * sin(t * 6.28 + s[3]));
      p.color = Colors.white.withOpacity(tw);
      final dy = (s[1] + t * 0.02 * s[2]) % 1.0;
      canvas.drawCircle(Offset(s[0] * size.width, dy * size.height), s[2], p);
    }
    canvas.drawCircle(
      Offset(size.width * 0.8, size.height * 0.15),
      120,
      Paint()..shader = RadialGradient(colors: [accent.withOpacity(0.18), Colors.transparent]).createShader(Rect.fromCircle(center: Offset(size.width * 0.8, size.height * 0.15), radius: 120)),
    );
  }

  @override
  bool shouldRepaint(covariant _StarPainter old) => old.t != t;
}
