import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import '../../core/store.dart';

/// منابع پیش‌فرض (آدرس raw فایل‌های متنی/JSON حاوی لینک پروکسی تلگرام).
/// آدرس معتبر خودتان را اینجا یا از «تنظیمات > منابع پروکسی» اضافه کنید.
const List<String> kDefaultProxySources = <String>[];

class ProxyEntry {
  final String server;
  final int port;
  final String secret;
  double? score; // کمتر = بهتر
  ProxyEntry(this.server, this.port, this.secret);

  String get key => '$server:$port';
  String get link => 'tg://proxy?server=$server&port=$port&secret=$secret';

  Map<String, dynamic> toJson() => {'s': server, 'p': port, 'k': secret};
  static ProxyEntry fromJson(Map<String, dynamic> j) => ProxyEntry(j['s'], j['p'], j['k']);
}

enum ConnState { idle, searching, connected, failed }

final proxyService = ProxyService();

class ProxyService extends ChangeNotifier {
  ConnState state = ConnState.idle;
  String status = 'آماده اتصال';
  ProxyEntry? current;
  DateTime? connectedAt;
  List<String> sources = [];
  Timer? _recheck;
  final _store = JsonStore('proxies.json');
  final _rnd = Random();

  Future<void> load() async {
    sources = await Prefs.getList('proxy_sources') ?? List<String>.of(kDefaultProxySources);
  }

  Future<void> addSource(String url) async {
    final u = url.trim();
    if (u.isEmpty || sources.contains(u)) return;
    sources.add(u);
    await Prefs.setList('proxy_sources', sources);
    notifyListeners();
  }

  Future<void> removeSource(String url) async {
    sources.remove(url);
    await Prefs.setList('proxy_sources', sources);
    notifyListeners();
  }

  List<ProxyEntry> _parse(String text) {
    final out = <ProxyEntry>[];
    final re = RegExp(r'server=([^&\s"<>]+)&(?:amp;)?port=(\d+)&(?:amp;)?secret=([A-Za-z0-9_\-=%]+)');
    for (final m in re.allMatches(text)) {
      final port = int.tryParse(m.group(2)!);
      if (port == null) continue;
      out.add(ProxyEntry(m.group(1)!, port, m.group(3)!));
    }
    return out;
  }

  Future<List<ProxyEntry>> _fetchAll() async {
    final map = <String, ProxyEntry>{};
    for (final src in sources) {
      try {
        final r = await http.get(Uri.parse(src)).timeout(const Duration(seconds: 15));
        if (r.statusCode == 200) {
          for (final e in _parse(utf8.decode(r.bodyBytes, allowMalformed: true))) {
            map[e.key] = e;
          }
        }
      } catch (_) {}
    }
    if (map.isNotEmpty) {
      await _store.write(map.values.map((e) => e.toJson()).toList());
    } else {
      // قطع اینترنت بین‌الملل: از فهرست ذخیره‌شده استفاده می‌شود
      final cached = await _store.read();
      if (cached is List) {
        for (final j in cached) {
          final e = ProxyEntry.fromJson(Map<String, dynamic>.from(j));
          map[e.key] = e;
        }
      }
    }
    return map.values.toList();
  }

  /// کیفیت واقعی: میانگین تأخیر سه تلاش + جریمهٔ تلاش‌های ناموفق
  Future<double?> _quality(ProxyEntry e) async {
    var ok = 0;
    var total = 0;
    for (var i = 0; i < 3; i++) {
      final sw = Stopwatch()..start();
      try {
        final s = await Socket.connect(e.server, e.port, timeout: const Duration(seconds: 3));
        sw.stop();
        s.destroy();
        ok++;
        total += sw.elapsedMilliseconds;
      } catch (_) {}
    }
    if (ok == 0) return null;
    return total / ok + (3 - ok) * 800;
  }

  Future<ProxyEntry?> _pickBest() async {
    final all = await _fetchAll();
    if (all.isEmpty) return null;
    all.shuffle(_rnd);
    final sample = all.take(40).toList();
    final good = <ProxyEntry>[];
    for (var i = 0; i < sample.length; i += 10) {
      final batch = sample.skip(i).take(10).toList();
      final res = await Future.wait(batch.map(_quality));
      for (var j = 0; j < batch.length; j++) {
        if (res[j] != null) {
          batch[j].score = res[j];
          good.add(batch[j]);
        }
      }
    }
    if (good.isEmpty) return null;
    good.sort((a, b) => a.score!.compareTo(b.score!));
    final top = good.take(5).toList(); // انتخاب تصادفی از میان بهترین‌ها (توزیع بار)
    return top[_rnd.nextInt(top.length)];
  }

  Future<void> connect() async {
    state = ConnState.searching;
    status = 'در حال بررسی کیفیت سرورها...';
    notifyListeners();
    final best = await _pickBest();
    if (best == null) {
      state = ConnState.failed;
      status = sources.isEmpty ? 'منبع پروکسی تعریف نشده' : 'سرور سالمی پیدا نشد';
      notifyListeners();
      return;
    }
    var launched = false;
    try {
      launched = await launchUrl(Uri.parse(best.link), mode: LaunchMode.externalApplication);
    } catch (_) {}
    if (!launched) {
      state = ConnState.failed;
      status = 'تلگرام روی گوشی پیدا نشد';
      notifyListeners();
      return;
    }
    current = best;
    connectedAt = DateTime.now();
    state = ConnState.connected;
    status = 'سرور ${best.server} (${best.score!.round()}ms) را در تلگرام تأیید کنید';
    _recheck?.cancel();
    _recheck = Timer.periodic(const Duration(minutes: 10), (_) => _reevaluate());
    notifyListeners();
  }

  /// ارزیابی دوبارهٔ هر ۱۰ دقیقه؛ اگر سرور فعلی از دسترس خارج شده باشد، سرور جدید معرفی می‌شود
  Future<void> _reevaluate() async {
    final c = current;
    if (state != ConnState.connected || c == null) return;
    final q = await _quality(c);
    if (q == null) await connect();
  }

  void disconnect() {
    _recheck?.cancel();
    state = ConnState.idle;
    status = 'قطع شد (پروکسی را در تنظیمات تلگرام هم می‌توانید خاموش کنید)';
    connectedAt = null;
    current = null;
    notifyListeners();
  }
}
