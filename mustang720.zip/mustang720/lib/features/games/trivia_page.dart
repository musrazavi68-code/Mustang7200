import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/store.dart';
import '../../core/widgets.dart';
import '../news/news_service.dart';

class TQ {
  final String cat;
  final String q;
  final List<String> options; // گزینهٔ اول همیشه درست است و هنگام بازی بُر می‌خورد
  const TQ(this.cat, this.q, this.options);
}

const kCats = {
  'football': 'فوتبال',
  'history': 'سیاست و تاریخ',
  'military': 'نظامی',
  'literature': 'ادبیات',
  'tech': 'فناوری',
};

const kQuestions = <TQ>[
  TQ('football', 'قهرمان جام جهانی ۲۰۱۸ کدام تیم بود؟', ['فرانسه', 'کرواسی', 'برزیل', 'آلمان']),
  TQ('football', 'جام جهانی ۲۰۲۲ در کدام کشور برگزار شد؟', ['قطر', 'روسیه', 'برزیل', 'آفریقای جنوبی']),
  TQ('football', 'هر تیم فوتبال چند بازیکن در زمین دارد؟', ['۱۱', '۹', '۱۰', '۱۲']),
  TQ('football', 'نقطهٔ پنالتی چند متر از خط دروازه فاصله دارد؟', ['۱۱', '۹', '۱۲', '۱۶']),
  TQ('football', 'کدام کشور بیشترین قهرمانی جام جهانی مردان را دارد؟', ['برزیل', 'آلمان', 'ایتالیا', 'آرژانتین']),
  TQ('football', 'جام جهانی هر چند سال یک‌بار برگزار می‌شود؟', ['۴ سال', '۲ سال', '۳ سال', '۵ سال']),
  TQ('history', 'بنیان‌گذار شاهنشاهی هخامنشی کیست؟', ['کوروش بزرگ', 'داریوش', 'خشایارشا', 'اردشیر']),
  TQ('history', 'فرمان مشروطه در چه سالی صادر شد؟', ['۱۲۸۵ شمسی', '۱۲۹۹ شمسی', '۱۳۰۴ شمسی', '۱۲۷۰ شمسی']),
  TQ('history', 'سازمان ملل متحد در چه سالی تأسیس شد؟', ['۱۹۴۵ میلادی', '۱۹۱۹ میلادی', '۱۹۵۰ میلادی', '۱۹۳۹ میلادی']),
  TQ('history', 'تخت جمشید در کدام استان است؟', ['فارس', 'اصفهان', 'خوزستان', 'یزد']),
  TQ('history', 'جنگ جهانی اول در چه سالی آغاز شد؟', ['۱۹۱۴', '۱۹۱۸', '۱۹۳۹', '۱۹۰۵']),
  TQ('history', 'پس از قزوین، پایتخت صفویان کدام شهر شد؟', ['اصفهان', 'تبریز', 'شیراز', 'مشهد']),
  TQ('military', 'نخستین کشوری که بمب اتمی ساخت کدام است؟', ['آمریکا', 'شوروی', 'انگلستان', 'آلمان']),
  TQ('military', 'کشتی‌ای که روی عرشه‌اش باند پرواز دارد چه نام دارد؟', ['ناو هواپیمابر', 'ناوچه', 'زیردریایی', 'نفتکش']),
  TQ('military', 'رادار برای چه کاری به‌کار می‌رود؟', ['شناسایی اهداف با امواج رادیویی', 'ارتباط تلفنی', 'تصفیهٔ آب', 'پخش تلویزیونی']),
  TQ('military', 'جنگ جهانی دوم در چه سالی آغاز شد؟', ['۱۹۳۹', '۱۹۱۴', '۱۹۴۵', '۱۹۳۳']),
  TQ('military', 'پهپاد یعنی چه؟', ['هواپیمای بدون سرنشین', 'زیردریایی کوچک', 'تانک سبک', 'موشک بالستیک']),
  TQ('military', 'تنگهٔ هرمز خلیج فارس را به کدام دریا وصل می‌کند؟', ['دریای عمان', 'دریای خزر', 'دریای سرخ', 'مدیترانه']),
  TQ('literature', 'شاهنامه سروده کیست؟', ['فردوسی', 'سعدی', 'حافظ', 'نظامی']),
  TQ('literature', 'گلستان و بوستان از کیست؟', ['سعدی', 'مولوی', 'عطار', 'خیام']),
  TQ('literature', 'مثنوی معنوی اثر کیست؟', ['مولوی', 'سنایی', 'فردوسی', 'جامی']),
  TQ('literature', 'خمسه (پنج گنج) از کیست؟', ['نظامی گنجوی', 'عطار', 'حافظ', 'ناصرخسرو']),
  TQ('literature', 'پدر رستم در شاهنامه چه نام دارد؟', ['زال', 'سام', 'گرشاسب', 'فریدون']),
  TQ('literature', 'دیوان کدام شاعر برای فال‌گرفتن شهرت دارد؟', ['حافظ', 'سعدی', 'مولوی', 'نیما']),
  TQ('tech', 'AI مخفف چیست؟', ['هوش مصنوعی', 'اینترنت پیشرفته', 'ارتباط آنلاین', 'آدرس اینترنتی']),
  TQ('tech', 'سیستم‌عامل اندروید را کدام شرکت توسعه می‌دهد؟', ['گوگل', 'اپل', 'مایکروسافت', 'سامسونگ']),
  TQ('tech', 'CPU به فارسی چه معنایی دارد؟', ['واحد پردازش مرکزی', 'کارت گرافیک', 'حافظهٔ موقت', 'منبع تغذیه']),
  TQ('tech', 'HTML برای چه کاری استفاده می‌شود؟', ['ساختار صفحات وب', 'ویرایش عکس', 'ساخت بازی سه‌بعدی', 'مدیریت پایگاه داده']),
  TQ('tech', 'Wi-Fi برای چه کاری به‌کار می‌رود؟', ['اتصال بی‌سیم به شبکه', 'شارژ باتری', 'ضبط صدا', 'چاپ سند']),
  TQ('tech', 'هر بایت چند بیت است؟', ['۸', '۴', '۱۶', '۲']),
];

class TriviaPage extends StatefulWidget {
  const TriviaPage({super.key});
  @override
  State<TriviaPage> createState() => _TriviaPageState();
}

class _TriviaPageState extends State<TriviaPage> {
  final _rnd = Random();
  String? _cat;
  List<TQ> _round = [];
  int _i = 0;
  int _score = 0;
  int _coins = 0;
  bool _hint = false;
  bool _answered = false;
  List<String> _opts = [];
  Set<String> _removed = {};
  String? _picked;
  late Stopwatch _sw;

  /// پیشنهاد بر اساس دستهٔ خبری که کاربر بیشتر می‌خواند
  String _suggest() {
    final counts = <String, int>{};
    for (final a in newsService.articles.where((a) => a.read)) {
      final k = {'ورزشی': 'football', 'فناوری': 'tech', 'سیاسی': 'history'}[a.category];
      if (k != null) counts[k] = (counts[k] ?? 0) + 1;
    }
    if (counts.isEmpty) return kCats.keys.elementAt(_rnd.nextInt(kCats.length));
    return (counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).first.key;
  }

  void _start(String cat) {
    final l = kQuestions.where((q) => q.cat == cat).toList()..shuffle(_rnd);
    setState(() {
      _cat = cat;
      _round = l.take(5).toList();
      _i = 0;
      _score = 0;
      _coins = 0;
      _prepare();
    });
  }

  void _prepare() {
    _opts = List<String>.of(_round[_i].options)..shuffle(_rnd);
    _removed = {};
    _hint = false;
    _answered = false;
    _picked = null;
    _sw = Stopwatch()..start();
  }

  void _useHint() {
    if (_hint || _answered) return;
    final correct = _round[_i].options.first;
    final wrong = _opts.where((o) => o != correct).toList()..shuffle(_rnd);
    setState(() {
      _hint = true;
      _removed = wrong.take(2).toSet();
    });
  }

  Future<void> _pick(String o) async {
    if (_answered) return;
    _sw.stop();
    final ok = o == _round[_i].options.first;
    final secs = _sw.elapsedMilliseconds / 1000;
    setState(() {
      _answered = true;
      _picked = o;
      if (ok) {
        var s = max(100, 1000 - (secs * 80).round());
        if (_hint) s = max(0, s - 100);
        _score += s;
        _coins += secs <= 4 ? 2 : 1;
      }
    });
    await Future<void>.delayed(const Duration(milliseconds: 1100));
    if (!mounted) return;
    if (_i + 1 >= _round.length) {
      await Prefs.setInt('trivia_score', await Prefs.getInt('trivia_score') + _score);
      await Prefs.setInt('coins', await Prefs.getInt('coins') + _coins);
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('پایان دور'),
          content: Text('امتیاز: $_score\nسکه: $_coins'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('باشه'))],
        ),
      );
      if (mounted) setState(() => _cat = null);
    } else {
      setState(() {
        _i++;
        _prepare();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_cat == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('جدول اطلاعات عمومی')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('موضوع موردعلاقه‌ات را انتخاب کن:', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            SizedBox(height: 54, child: Key3D(color: const Color(0xFFFFE08A), onTap: () => _start(_suggest()), child: const Text('✨ پیشنهاد برای من', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF23262B))))),
            const SizedBox(height: 12),
            for (final e in kCats.entries)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: SizedBox(height: 54, child: Key3D(color: const Color(0xFFBFD7FF), onTap: () => _start(e.key), child: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF23262B))))),
              ),
          ],
        ),
      );
    }
    final q = _round[_i];
    return Scaffold(
      appBar: AppBar(title: Text('${kCats[_cat]} • ${_i + 1}/${_round.length}'), actions: [
        Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text('امتیاز $_score'))),
      ]),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 12),
            Text(q.q, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, height: 1.7)),
            const SizedBox(height: 24),
            for (final o in _opts)
              if (!_removed.contains(o))
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: SizedBox(
                    height: 54,
                    child: Key3D(
                      color: !_answered
                          ? const Color(0xFFC9B8FF)
                          : (o == q.options.first ? const Color(0xFFA8F5C8) : (o == _picked ? const Color(0xFFFF8A8A) : const Color(0xFFE3E0EC))),
                      onTap: () => _pick(o),
                      child: Text(o, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF23262B))),
                    ),
                  ),
                ),
            const Spacer(),
            OutlinedButton.icon(
              onPressed: _hint || _answered ? null : _useHint,
              icon: const Icon(Icons.lightbulb_outline),
              label: const Text('راهنما (۱۰۰- امتیاز)'),
            ),
          ],
        ),
      ),
    );
  }
}
