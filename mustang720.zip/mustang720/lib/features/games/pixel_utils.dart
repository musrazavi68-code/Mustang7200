import 'package:flutter/material.dart';

/// نوشتن متن روی بوم بازی (راست‌به‌چپ)
Size drawText(Canvas c, String s, Offset o, double size, Color col,
    {bool bold = true, TextAlign align = TextAlign.left, double? width}) {
  final tp = TextPainter(
    text: TextSpan(text: s, style: TextStyle(fontSize: size, color: col, fontWeight: bold ? FontWeight.w800 : FontWeight.w400)),
    textDirection: TextDirection.rtl,
  )..layout();
  var pos = o;
  if (align == TextAlign.center) pos = Offset(o.dx - tp.width / 2, o.dy);
  if (align == TextAlign.right) pos = Offset(o.dx - tp.width, o.dy);
  tp.paint(c, pos);
  return tp.size;
}

/// ابر گفت‌وگو
void drawBubble(Canvas c, String s, Offset center, double size) {
  final tp = TextPainter(
    text: TextSpan(text: s, style: TextStyle(fontSize: size, color: Colors.black, fontWeight: FontWeight.w800)),
    textDirection: TextDirection.rtl,
  )..layout();
  final rect = Rect.fromCenter(center: center, width: tp.width + 14, height: tp.height + 10);
  c.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), Paint()..color = Colors.white);
  c.drawRect(Rect.fromLTWH(center.dx - 3, rect.bottom, 6, 5), Paint()..color = Colors.white);
  tp.paint(c, Offset(rect.left + 7, rect.top + 5));
}

/// اسپرایت پیکسلی از روی ردیف‌های متنی
void drawSprite(Canvas c, List<String> rows, Map<String, Color> pal, double x, double y, double px) {
  final p = Paint()..isAntiAlias = false;
  for (var r = 0; r < rows.length; r++) {
    final row = rows[r];
    for (var k = 0; k < row.length; k++) {
      final col = pal[row[k]];
      if (col == null) continue;
      p.color = col;
      c.drawRect(Rect.fromLTWH(x + k * px, y + r * px, px, px), p);
    }
  }
}
