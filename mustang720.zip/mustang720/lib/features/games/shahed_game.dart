import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import '../../core/store.dart';
import 'pixel_utils.dart';

class _E {
  final String type; // barrel | jet | ship
  double x, y;
  double baseX;
  double hp;
  final double w, h;
  double t = 0, shootT;
  _E(this.type, this.x, this.y, this.hp, this.w, this.h, this.shootT) : baseX = x;
}

class _B {
  double x, y, vx, vy;
  double dmg;
  _B(this.x, this.y, this.vx, this.vy, [this.dmg = 1]);
}

class _Item {
  double x, y;
  String kind; // gift | coin
  _Item(this.x, this.y, this.kind);
}

class _P {
  double x, y, vx, vy, life;
  Color c;
  _P(this.x, this.y, this.vx, this.vy, this.life, this.c);
}

const _powerNames = {
  'rapid': 'تیربار',
  'power': 'قدرت شلیک بیشتر',
  'shield': 'سپر محافظ',
  'multi': 'شلیک چندگانه',
  'heal': 'افزایش سلامتی',
  'magnet': 'آهنربای سکه',
};

class ShahedGame {
  final rnd = Random();
  double W = 320, H = 600;
  String state = 'play'; // play | ending | won | over
  double time = 0, scroll = 0, endT = 0;
  double px = 160, py = -1;
  double health = 100;
  int coinCount = 0, kills = 0;
  double fireT = 0, spawnT = 1;
  double rapidT = 0, powerT = 0, shieldT = 0, multiT = 0, magnetT = 0, hurt = 0;
  String msg = '';
  double msgT = 0;
  final List<_B> bullets = [];
  final List<_B> ebullets = [];
  final List<_E> enemies = [];
  final List<_Item> items = [];
  final List<_P> parts = [];
  // غول نهایی
  bool bossSpawned = false;
  double bossHp = 0, bossT = 0, bossShoot = 0, bossX = 160;
  static const double bossMax = 200; // دو برابر سلامتی پهپاد
  static const double bossY = 120;

  int get score => kills * 10 + coinCount * 5;
  bool get bossAlive => bossSpawned && bossHp > 0;

  void reset() {
    state = 'play';
    time = 0;
    scroll = 0;
    endT = 0;
    py = -1;
    health = 100;
    coinCount = 0;
    kills = 0;
    fireT = 0;
    spawnT = 1;
    rapidT = powerT = shieldT = multiT = magnetT = hurt = 0;
    msgT = 0;
    bullets.clear();
    ebullets.clear();
    enemies.clear();
    items.clear();
    parts.clear();
    bossSpawned = false;
    bossHp = 0;
  }

  void move(double dx, double dy) {
    if (state != 'play') return;
    px = (px + dx).clamp(16.0, W - 16).toDouble();
    py = (py + dy).clamp(80.0, H - 40).toDouble();
  }

  void _toast(String s) {
    msg = s;
    msgT = 1.6;
  }

  void _burst(double x, double y, Color c, [int n = 10]) {
    for (var i = 0; i < n; i++) {
      final a = rnd.nextDouble() * 2 * pi;
      final sp = 40 + rnd.nextDouble() * 110;
      parts.add(_P(x, y, cos(a) * sp, sin(a) * sp, 0.4 + rnd.nextDouble() * 0.3, c));
    }
  }

  void _hit(double dmg) {
    if (shieldT > 0) return;
    health -= dmg;
    hurt = 0.4;
    if (health <= 0) {
      health = 0;
      state = 'over';
    }
  }

  void _givePower() {
    final k = _powerNames.keys.elementAt(rnd.nextInt(_powerNames.length));
    switch (k) {
      case 'rapid':
        rapidT = 8;
        break;
      case 'power':
        powerT = 8;
        break;
      case 'shield':
        shieldT = 6;
        break;
      case 'multi':
        multiT = 8;
        break;
      case 'heal':
        health = min(100.0, health + 30);
        break;
      case 'magnet':
        magnetT = 8;
        break;
    }
    _toast(_powerNames[k]!);
  }

  void _spawn() {
    final r = rnd.nextDouble();
    final x = 30 + rnd.nextDouble() * (W - 60);
    if (r < 0.5) {
      enemies.add(_E('barrel', x, -30, 2, 30, 30, 1 + rnd.nextDouble()));
    } else if (r < 0.85) {
      enemies.add(_E('jet', x, -30, 1, 26, 26, 0.6 + rnd.nextDouble()));
    } else {
      enemies.add(_E('ship', x, -30, 5, 56, 26, 1.5));
    }
  }

  void _kill(_E e) {
    kills += e.type == 'ship' ? 4 : (e.type == 'barrel' ? 2 : 1);
    _burst(e.x, e.y, const Color(0xFFFFC107), 12);
    final n = 1 + rnd.nextInt(3);
    for (var i = 0; i < n; i++) {
      items.add(_Item(e.x + i * 10 - 10, e.y, 'coin'));
    }
    if (rnd.nextDouble() < 0.14) items.add(_Item(e.x, e.y, 'gift'));
  }

  void update(double dt) {
    if (state == 'over' || state == 'won') return;
    time += dt;
    scroll += 70 * dt;
    if (py < 0) py = H - 120;
    if (msgT > 0) msgT -= dt;
    if (hurt > 0) hurt -= dt;

    if (state == 'ending') {
      endT += dt;
      py -= 50 * dt;
      for (final p in parts) {
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.life -= dt;
      }
      parts.removeWhere((p) => p.life <= 0);
      if (endT > 9) state = 'won';
      return;
    }

    if (rapidT > 0) rapidT -= dt;
    if (powerT > 0) powerT -= dt;
    if (shieldT > 0) shieldT -= dt;
    if (multiT > 0) multiT -= dt;
    if (magnetT > 0) magnetT -= dt;

    // شلیک خودکار
    fireT -= dt;
    if (fireT <= 0) {
      fireT = rapidT > 0 ? 0.12 : 0.28;
      final d = powerT > 0 ? 2.0 : 1.0;
      bullets.add(_B(px, py - 20, 0, -520, d));
      if (multiT > 0) {
        bullets.add(_B(px - 8, py - 16, -70, -500, d));
        bullets.add(_B(px + 8, py - 16, 70, -500, d));
      }
    }

    // تولید دشمن و غول
    if (!bossSpawned && (kills >= 40 || time > 75)) {
      bossSpawned = true;
      bossHp = bossMax;
      bossT = 0;
      bossShoot = 1.5;
      _toast('غول نهایی از راه رسید!');
    }
    spawnT -= dt;
    if (spawnT <= 0) {
      if (!bossAlive || enemies.length < 2) _spawn();
      spawnT = max(0.45, 1.4 - time * 0.01) * (bossAlive ? 2.2 : 1);
    }

    // گلوله‌های بازیکن
    for (final b in bullets) {
      b.x += b.vx * dt;
      b.y += b.vy * dt;
    }
    bullets.removeWhere((b) => b.y < -20 || b.x < -20 || b.x > W + 20);

    // دشمن‌ها
    for (final e in enemies) {
      e.t += dt;
      if (e.type == 'barrel') {
        e.y += 55 * dt;
        e.x = (e.baseX + sin(e.t * 2) * 40).clamp(20.0, W - 20).toDouble();
      } else if (e.type == 'jet') {
        e.y += 150 * dt;
        e.x = (e.baseX + sin(e.t * 3) * 25).clamp(20.0, W - 20).toDouble();
      } else {
        e.y += 30 * dt;
        e.x = (e.baseX + sin(e.t) * 60).clamp(30.0, W - 30).toDouble();
      }
      e.shootT -= dt;
      if (e.shootT <= 0 && e.y > 10 && e.y < H - 160) {
        if (e.type == 'barrel') {
          ebullets.add(_B(e.x, e.y + 16, (px - e.x) * 0.25, 140));
          e.shootT = 2.2;
        } else if (e.type == 'jet') {
          ebullets.add(_B(e.x, e.y + 14, 0, 230));
          e.shootT = 1.6;
        } else {
          for (final vx in [-60.0, 0.0, 60.0]) {
            ebullets.add(_B(e.x, e.y + 14, vx, 170));
          }
          e.shootT = 2.5;
        }
      }
      for (final b in bullets) {
        if ((b.x - e.x).abs() < e.w / 2 + 3 && (b.y - e.y).abs() < e.h / 2 + 4 && b.dmg > 0) {
          e.hp -= b.dmg;
          b.dmg = 0;
          b.y = -999;
        }
      }
      if ((e.x - px).abs() < e.w / 2 + 10 && (e.y - py).abs() < e.h / 2 + 10 && e.hp > 0) {
        e.hp = 0;
        _hit(20);
        _burst(e.x, e.y, Colors.redAccent);
      } else if (e.hp <= 0) {
        _kill(e);
      }
    }
    enemies.removeWhere((e) => e.hp <= 0 || e.y > H + 40);

    // غول
    if (bossAlive) {
      bossT += dt;
      bossX = W / 2 + sin(bossT * 0.8) * (W / 2 - 70);
      bossShoot -= dt;
      if (bossShoot <= 0) {
        for (var i = -2; i <= 2; i++) {
          ebullets.add(_B(bossX + i * 18, bossY + 40, i * 55.0, 190));
        }
        bossShoot = 1.1;
      }
      for (final b in bullets) {
        if ((b.x - bossX).abs() < 56 && (b.y - bossY).abs() < 44 && b.dmg > 0) {
          bossHp -= b.dmg;
          b.dmg = 0;
          b.y = -999;
          items.add(_Item(b.x, bossY + 40, 'coin')); // سکهٔ ستاره‌ای
          _burst(b.x, bossY + 20, const Color(0xFFB39DDB), 3);
        }
      }
      if (bossHp <= 0) {
        bossHp = 0;
        _burst(bossX, bossY, const Color(0xFFFFC107), 40);
        state = 'ending';
        endT = 0;
        ebullets.clear();
        enemies.clear();
        return;
      }
    }
    bullets.removeWhere((b) => b.dmg <= 0);

    // گلوله‌های دشمن
    for (final b in ebullets) {
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      if ((b.x - px).abs() < 12 && (b.y - py).abs() < 14) {
        _hit(10);
        b.y = H + 99;
      }
    }
    ebullets.removeWhere((b) => b.y > H + 20 || b.x < -30 || b.x > W + 30);

    // سکه و جعبه
    for (final it in items) {
      if (it.kind == 'gift') {
        it.y += 70 * dt;
      } else {
        it.y += 80 * dt;
        if (magnetT > 0) {
          final dx = px - it.x, dy = py - it.y;
          final d = sqrt(dx * dx + dy * dy);
          if (d < 160 && d > 1) {
            it.x += dx / d * 260 * dt;
            it.y += dy / d * 260 * dt;
          }
        }
      }
      if ((it.x - px).abs() < 22 && (it.y - py).abs() < 24) {
        if (it.kind == 'coin') {
          coinCount++;
        } else {
          _givePower();
        }
        it.y = H + 99;
      } else if (it.kind == 'gift') {
        for (final b in bullets) {
          if ((b.x - it.x).abs() < 14 && (b.y - it.y).abs() < 14 && b.dmg > 0) {
            b.dmg = 0;
            _givePower();
            it.y = H + 99;
          }
        }
      }
    }
    items.removeWhere((i) => i.y > H + 30);

    for (final p in parts) {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;
    }
    parts.removeWhere((p) => p.life <= 0);
  }
}

class ShahedPage extends StatefulWidget {
  const ShahedPage({super.key});
  @override
  State<ShahedPage> createState() => _ShahedPageState();
}

class _ShahedPageState extends State<ShahedPage> with SingleTickerProviderStateMixin {
  final g = ShahedGame();
  late final Ticker _ticker;
  final ValueNotifier<int> _frame = ValueNotifier(0);
  Duration _last = Duration.zero;
  String _lastState = 'play';
  double _scale = 1;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_tick)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  void _tick(Duration d) {
    final dt = min(0.033, (d - _last).inMicroseconds / 1e6);
    _last = d;
    g.update(dt);
    _frame.value++;
    if (g.state != _lastState) {
      _lastState = g.state;
      setState(() {});
      if (g.state == 'over' || g.state == 'won') _finish();
    }
  }

  Future<void> _finish() async {
    _ticker.stop();
    final best = await Prefs.getInt('rec_shahed');
    if (g.score > best) await Prefs.setInt('rec_shahed', g.score);
    await Prefs.setInt('coins', await Prefs.getInt('coins') + g.coinCount);
  }

  void _restart() {
    g.reset();
    _last = Duration.zero;
    _lastState = 'play';
    _ticker.start();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: LayoutBuilder(builder: (context, box) {
              _scale = min(box.maxWidth / 320, box.maxHeight / 600);
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onPanUpdate: (d) => g.move(d.delta.dx / _scale, d.delta.dy / _scale),
                child: CustomPaint(painter: ShahedPainter(g, _frame)),
              );
            }),
          ),
          Positioned(
            left: 4,
            top: 4,
            child: SafeArea(child: IconButton(icon: const Icon(Icons.close, color: Colors.white54), onPressed: () => Navigator.pop(context))),
          ),
          if (g.state == 'over') _overlay('بازی تمام شد', 'امتیاز ${g.score} • سکه ${g.coinCount}'),
          if (g.state == 'won') _overlay('پایان بازی شاهد', 'امتیاز ${g.score} • سکه ${g.coinCount}'),
        ],
      ),
    );
  }

  Widget _overlay(String title, String info) {
    return Positioned.fill(
      child: Container(
        color: Colors.black54,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: Colors.amber)),
              const SizedBox(height: 10),
              Text(info, style: const TextStyle(color: Colors.white, fontSize: 16)),
              const SizedBox(height: 20),
              FilledButton(onPressed: _restart, child: const Text('شروع دوباره')),
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('خروج')),
            ],
          ),
        ),
      ),
    );
  }
}

class ShahedPainter extends CustomPainter {
  final ShahedGame g;
  ShahedPainter(this.g, Listenable repaint) : super(repaint: repaint);

  static const _drone = [
    '....11....',
    '...1111...',
    '..111111..',
    '.11122111.',
    '1111221111',
    '1..1111..1',
    '...1..1...',
  ];
  static const _boss = [
    '....11111111....',
    '..111111111111..',
    '.11111111111111.',
    '1111112222111111',
    '1111122332211111',
    '1111112222111111',
    '.11111111111111.',
    '1.1.11.11.11.1.1',
    '1.1.1..11..1.1.1',
    '.1..1..11..1..1.',
  ];
  static const _jet = [
    '...11...',
    '..1111..',
    '.111111.',
    '11211211',
    '1..11..1',
    '...11...',
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final s = min(size.width / 320, size.height / 600);
    g.W = size.width / s;
    g.H = size.height / s;
    final W = g.W, H = g.H;
    canvas.save();
    canvas.scale(s);
    final p = Paint()..isAntiAlias = false;
    void r(double x, double y, double w, double h, Color c) {
      p.color = c;
      canvas.drawRect(Rect.fromLTWH(x, y, w, h), p);
    }

    final bg = Rect.fromLTWH(0, 0, W, H);
    canvas.drawRect(bg, Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF0D2B45), Color(0xFF145A7A)]).createShader(bg));
    for (var k = 0; k < 26; k++) {
      final x = (k * 53.0) % W;
      final y = (k * 97.0 + g.scroll * (0.6 + (k % 3) * 0.3)) % H;
      r(x, y, 22, 2, const Color(0xFF2C86A8));
    }

    // آیتم‌ها
    for (final it in g.items) {
      if (it.kind == 'coin') {
        r(it.x - 5, it.y - 5, 10, 10, const Color(0xFFFFC107));
        r(it.x - 3, it.y - 3, 6, 6, const Color(0xFFFFE082));
      } else {
        r(it.x - 11, it.y - 11, 22, 22, const Color(0xFFE91E63));
        r(it.x - 11, it.y - 2, 22, 4, const Color(0xFFFFEB3B));
        r(it.x - 2, it.y - 11, 4, 22, const Color(0xFFFFEB3B));
      }
    }

    // دشمن‌ها
    for (final e in g.enemies) {
      if (e.type == 'barrel') {
        r(e.x - 14, e.y - 8, 28, 24, const Color(0xFFB5452F));
        r(e.x - 14, e.y - 1, 28, 3, const Color(0xFF3E2723));
        r(e.x - 14, e.y + 9, 28, 3, const Color(0xFF3E2723));
        r(e.x - 7, e.y - 16, 14, 10, const Color(0xFFF2C29B));
        r(e.x - 20, e.y - 4, 6, 4, const Color(0xFFF2C29B));
        r(e.x + 14, e.y - 4, 6, 4, const Color(0xFFF2C29B));
      } else if (e.type == 'jet') {
        drawSprite(canvas, _jet, const {'1': Color(0xFFB0BEC5), '2': Color(0xFFE53935)}, e.x - 12, e.y - 9, 3);
      } else {
        r(e.x - 28, e.y - 4, 56, 14, const Color(0xFF78909C));
        r(e.x - 14, e.y - 12, 28, 10, const Color(0xFFB0BEC5));
        r(e.x - 3, e.y - 22, 6, 10, const Color(0xFF546E7A));
      }
    }

    // غول
    if (g.bossAlive) {
      drawSprite(canvas, _boss, const {'1': Color(0xFF7E57C2), '2': Colors.white, '3': Colors.black}, g.bossX - 56, ShahedGame.bossY - 35, 7);
      r(W / 2 - 80, 8, 160, 8, Colors.black54);
      r(W / 2 - 79, 9, 158 * (g.bossHp / ShahedGame.bossMax), 6, const Color(0xFFB39DDB));
    }

    // گلوله‌ها
    for (final b in g.bullets) {
      r(b.x - 1.5, b.y - 6, 3, 10, const Color(0xFFFFF59D));
    }
    for (final b in g.ebullets) {
      r(b.x - 3, b.y - 3, 6, 6, const Color(0xFFFF5252));
    }

    // پهپاد
    if (g.py >= 0) {
      if (g.shieldT > 0) {
        canvas.drawCircle(Offset(g.px, g.py), 26, Paint()..color = const Color(0x5539FF88));
        canvas.drawCircle(Offset(g.px, g.py), 26, Paint()..color = const Color(0xFF39FF88)..style = PaintingStyle.stroke..strokeWidth = 2);
      }
      if (!(g.hurt > 0 && (g.time * 20).floor() % 2 == 0)) {
        drawSprite(canvas, _drone, const {'1': Color(0xFF9FB48B), '2': Color(0xFFE53935)}, g.px - 15, g.py - 11, 3);
      }
    }

    // ذرات
    for (final q in g.parts) {
      r(q.x, q.y, 4, 4, q.c);
    }

    // پایان: پرچم و سروده
    if (g.state == 'ending' || g.state == 'won') {
      final a = (g.endT / 4).clamp(0.0, 1.0).toDouble();
      final fx = W * 0.15, fw = W * 0.7, fy = H * 0.3, fh = H * 0.06;
      r(fx, fy, fw, fh, const Color(0xFF239F40).withOpacity(a));
      r(fx, fy + fh, fw, fh, Colors.white.withOpacity(a));
      r(fx, fy + fh * 2, fw, fh, const Color(0xFFDA0000).withOpacity(a));
      final t = (g.endT / 3).clamp(0.0, 1.0).toDouble();
      drawText(canvas, 'ای دشمن، این خاک، سرزمین من است', Offset(W / 2, H * 0.55), 14, Colors.white.withOpacity(t), align: TextAlign.center);
      drawText(canvas, 'جان من فدای خاک پاک میهنم', Offset(W / 2, H * 0.55 + 24), 14, Colors.white.withOpacity(t), align: TextAlign.center);
    }

    // HUD
    r(10, 10, 104, 10, Colors.black54);
    r(12, 12, g.health, 6, g.health > 40 ? const Color(0xFF43A047) : const Color(0xFFE53935));
    drawText(canvas, 'امتیاز ${g.score}', Offset(W - 10, 8), 12, Colors.white, align: TextAlign.right);
    drawText(canvas, 'سکه ${g.coinCount}', Offset(W - 10, 24), 12, const Color(0xFFFFE082), align: TextAlign.right);
    if (g.msgT > 0) drawText(canvas, g.msg, Offset(W / 2, 44), 15, const Color(0xFF39FF88), align: TextAlign.center);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant ShahedPainter old) => true;
}
