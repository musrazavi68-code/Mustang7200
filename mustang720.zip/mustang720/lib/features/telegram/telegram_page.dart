import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/util.dart';
import 'telegram_service.dart';

class TelegramPage extends StatefulWidget {
  const TelegramPage({super.key});
  @override
  State<TelegramPage> createState() => _TelegramPageState();
}

class _TelegramPageState extends State<TelegramPage> {
  Timer? _poll;
  String _q = '';
  String? _channel;

  @override
  void initState() {
    super.initState();
    telegramService.refresh();
    _poll = Timer.periodic(const Duration(minutes: 1), (_) => telegramService.refresh());
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  Future<void> _add() async {
    final c = TextEditingController();
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('افزودن کانال عمومی'),
        content: TextField(controller: c, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: '@channel_name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('افزودن')),
        ],
      ),
    );
    if (v != null) telegramService.addChannel(v);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: telegramService,
      builder: (context, _) {
        final list = telegramService.messages.where((m) {
          if (_channel != null && m.channel != _channel) return false;
          if (_q.isNotEmpty && !m.text.contains(_q)) return false;
          return true;
        }).toList();
        return Scaffold(
          appBar: AppBar(
            title: const Text('کانال‌های تلگرام'),
            actions: [
              IconButton(icon: const Icon(Icons.refresh), onPressed: telegramService.refresh),
            ],
          ),
          floatingActionButton: FloatingActionButton(onPressed: _add, child: const Icon(Icons.add)),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
                child: TextField(
                  onChanged: (v) => setState(() => _q = v),
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'جست‌وجو در آرشیو آفلاین', isDense: true, border: OutlineInputBorder()),
                ),
              ),
              SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ChoiceChip(label: const Text('همه'), selected: _channel == null, onSelected: (_) => setState(() => _channel = null)),
                    ),
                    for (final c in telegramService.channels)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: GestureDetector(
                          onLongPress: () => telegramService.removeChannel(c),
                          child: ChoiceChip(label: Text('@$c'), selected: _channel == c, onSelected: (_) => setState(() => _channel = c)),
                        ),
                      ),
                  ],
                ),
              ),
              if (telegramService.refreshing) const LinearProgressIndicator(minHeight: 2),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: telegramService.refresh,
                  child: list.isEmpty
                      ? ListView(children: const [
                          SizedBox(height: 120),
                          Center(child: Padding(padding: EdgeInsets.all(24), child: Text('کانالی اضافه نشده یا پیامی ذخیره نشده.\nبا «+» کانال عمومی اضافه کنید. (نگه‌داشتن روی نام کانال = حذف)', textAlign: TextAlign.center))),
                        ])
                      : ListView.builder(
                          physics: const AlwaysScrollableScrollPhysics(),
                          itemCount: list.length,
                          itemBuilder: (c, i) {
                            final m = list[i];
                            return Card(
                              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                              child: InkWell(
                                onTap: () => launchUrl(Uri.parse(m.id), mode: LaunchMode.externalApplication),
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('@${m.channel} • ${timeAgo(m.time)}', style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.primary)),
                                      if (m.image != null)
                                        Padding(
                                          padding: const EdgeInsets.only(top: 8),
                                          child: ClipRRect(borderRadius: BorderRadius.circular(10), child: CachedNetworkImage(imageUrl: m.image!, errorWidget: (c, u, e) => const SizedBox())),
                                        ),
                                      if (m.text.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(m.text, maxLines: 8, overflow: TextOverflow.ellipsis)),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class InstagramPage extends StatelessWidget {
  const InstagramPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('استوری اینستاگرام')),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(28),
          child: Text(
            'اینستاگرام API رسمی برای دریافت استوری صفحات دیگران ارائه نمی‌دهد.\n\n'
            'این بخش نیازمند یک سرویس سمت‌سرور با مجوز رسمی است و در این نسخه پیاده‌سازی نشده. '
            'ساختار آرشیو (ذخیرهٔ تصویر، ویدئو و متن) مانند بخش تلگرام آمادهٔ اتصال است.',
            textAlign: TextAlign.center,
            style: TextStyle(height: 1.8),
          ),
        ),
      ),
    );
  }
}
