import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/util.dart';
import 'news_models.dart';
import 'news_service.dart';

class ArticlePage extends StatefulWidget {
  final Article article;
  const ArticlePage(this.article, {super.key});
  @override
  State<ArticlePage> createState() => _ArticlePageState();
}

class _ArticlePageState extends State<ArticlePage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => newsService.markRead(widget.article));
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.article;
    final imgs = RegExp(r'''<img[^>]+src=["']([^"']+)["']''', caseSensitive: false)
        .allMatches(a.content)
        .map((m) => m.group(1)!)
        .toSet()
        .toList();
    if (a.image != null && !imgs.contains(a.image)) imgs.insert(0, a.image!);
    final body = stripHtml(a.content);
    return Scaffold(
      appBar: AppBar(
        title: Text(a.feedTitle),
        actions: [
          IconButton(
            icon: Icon(a.starred ? Icons.star : Icons.star_border, color: a.starred ? Colors.amber : null),
            onPressed: () async {
              await newsService.toggleStar(a);
              setState(() {});
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.amber,
        foregroundColor: Colors.black,
        onPressed: () => Share.share('${a.title}\n${a.link}'),
        child: const Icon(Icons.share),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        children: [
          Text(a.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, height: 1.6)),
          const SizedBox(height: 6),
          Text('${timeAgo(a.published)} • ${a.category}', style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.primary)),
          const SizedBox(height: 14),
          for (final u in imgs.take(6))
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: CachedNetworkImage(imageUrl: u, errorWidget: (c, x, e) => const SizedBox()),
              ),
            ),
          if (body.isNotEmpty) Text(body, style: const TextStyle(fontSize: 15, height: 1.9)),
          const SizedBox(height: 20),
          FilledButton.tonal(
            onPressed: () => launchUrl(Uri.parse(a.link), mode: LaunchMode.externalApplication),
            child: const Text('ورود به سایت'),
          ),
        ],
      ),
    );
  }
}
