class Feed {
  final String id;
  final String title;
  final String url;
  final String category;
  const Feed(this.id, this.title, this.url, this.category);

  Map<String, dynamic> toJson() => {'id': id, 't': title, 'u': url, 'c': category};
  static Feed fromJson(Map<String, dynamic> j) => Feed(j['id'], j['t'], j['u'], j['c'] ?? 'عمومی');
}

class Article {
  final String id; // همان لینک مقاله
  final String feedId;
  final String feedTitle;
  final String category;
  final String title;
  final String link;
  final String content; // HTML یا متن خام
  final String? image;
  final DateTime published;
  final DateTime fetched;
  bool read;
  bool starred;

  Article({
    required this.id,
    required this.feedId,
    required this.feedTitle,
    required this.category,
    required this.title,
    required this.link,
    required this.content,
    required this.published,
    required this.fetched,
    this.image,
    this.read = false,
    this.starred = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'f': feedId,
        'ft': feedTitle,
        'c': category,
        't': title,
        'l': link,
        'b': content,
        'i': image,
        'p': published.millisecondsSinceEpoch,
        'g': fetched.millisecondsSinceEpoch,
        'r': read,
        's': starred,
      };

  static Article fromJson(Map<String, dynamic> j) => Article(
        id: j['id'],
        feedId: j['f'],
        feedTitle: j['ft'],
        category: j['c'] ?? 'عمومی',
        title: j['t'],
        link: j['l'],
        content: j['b'] ?? '',
        image: j['i'],
        published: DateTime.fromMillisecondsSinceEpoch(j['p']),
        fetched: DateTime.fromMillisecondsSinceEpoch(j['g']),
        read: j['r'] ?? false,
        starred: j['s'] ?? false,
      );
}
