import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../telegram/telegram_page.dart';
import 'article_page.dart';
import 'news_models.dart';
import 'news_service.dart';
import 'settings_page.dart';

class NewsPage extends StatefulWidget {
  const NewsPage({super.key});
  @override
  State<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  String _kind = 'unread'; // unread | last24 | starred | all | feed
  String? _feedId;
  String? _cat;
  String _q = '';
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    if (newsService.articles.isEmpty) WidgetsBinding.instance.addPostFrameCallback((_) => _refresh());
  }

  Future<void> _refresh() async {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('آغاز به‌روزرسانی'), duration: Duration(seconds: 1)));
    await newsService.refresh();
  }

  List<Article> _visible() {
    final now = DateTime.now();
    var l = newsService.articles.where((a) {
      switch (_kind) {
        case 'unread':
          if (a.read) return false;
          break;
        case 'last24':
          if (now.difference(a.published).inHours >= 24) return false;
          break;
        case 'starred':
          if (!a.starred) return false;
          break;
        case 'feed':
          if (a.feedId != _feedId) return false;
          break;
      }
      if (_cat != null && a.category != _cat) return false;
      if (newsService.hideRead && a.read) return false;
      if (_q.isNotEmpty && !a.title.contains(_q)) return false;
      return true;
    }).toList();
    return newsService.sorted(l);
  }

  String _title(int n) {
    switch (_kind) {
      case 'unread':
        return 'تمام خوانده‌نشده‌ها ($n)';
      case 'last24':
        return '۲۴ ساعت گذشته ($n)';
      case 'starred':
        return 'ستاره‌دارها ($n)';
      case 'feed':
        final f = newsService.feeds.where((e) => e.id == _feedId);
        return '${f.isEmpty ? '' : f.first.title} ($n)';
      default:
        return 'همهٔ اخبار ($n)';
    }
  }

  void _open(Article a) => Navigator.push(context, MaterialPageRoute(builder: (_) => ArticlePage(a)));

  Future<void> _sortDialog() async {
    const labels = {
      SortMode.unreadFirst: 'ابتدا خوانده‌نشده',
      SortMode.readFirst: 'ابتدا خوانده‌شده',
      SortMode.dateAsc: 'تاریخ (قدیمی‌ترین)',
      SortMode.dateDesc: 'تاریخ (جدیدترین)',
      SortMode.fetchAsc: 'زمان دریافت (قدیمی‌ترین)',
      SortMode.fetchDesc: 'زمان دریافت (جدیدترین)',
      SortMode.title: 'عنوان',
    };
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('مرتب‌سازی'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final e in labels.entries)
                ListTile(
                  dense: true,
                  leading: Icon(newsService.sort == e.key ? Icons.radio_button_checked : Icons.radio_button_off, color: Theme.of(ctx).colorScheme.primary),
                  title: Text(e.value),
                  onTap: () {
                    newsService.setSort(e.key);
                    Navigator.pop(ctx);
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirm(String msg, VoidCallback ok) async {
    final r = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(msg),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأیید')),
        ],
      ),
    );
    if (r == true) ok();
  }

  void _menu(String v) {
    switch (v) {
      case 'hide':
        newsService.toggleHideRead();
        break;
      case 'markall':
        newsService.markAllRead(_visible());
        break;
      case 'delall':
        _confirm('همهٔ اخبار (به‌جز ستاره‌دارها) حذف شود؟', () => newsService.deleteWhere((a) => true));
        break;
      case 'delread':
        newsService.deleteWhere((a) => a.read);
        break;
      case 'sort':
        _sortDialog();
        break;
      case 'layout':
        newsService.cycleLayout();
        break;
    }
  }

  Widget _placeholder() => Container(
        color: Theme.of(context).colorScheme.surface,
        child: const Center(child: Icon(Icons.article_outlined, color: Colors.white24)),
      );

  Widget _tile(Article a) {
    return GestureDetector(
      onTap: () => _open(a),
      onLongPress: () => newsService.toggleStar(a),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Stack(
          fit: StackFit.expand,
          children: [
            a.image != null
                ? CachedNetworkImage(imageUrl: a.image!, fit: BoxFit.cover, placeholder: (c, u) => _placeholder(), errorWidget: (c, u, e) => _placeholder())
                : _placeholder(),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xE6000000)], stops: [0.35, 1]),
              ),
            ),
            Positioned(
              left: 6,
              right: 6,
              bottom: 6,
              child: Text(
                a.title,
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: a.read ? Colors.white60 : Colors.white, fontSize: 11, height: 1.35, fontWeight: FontWeight.w700),
              ),
            ),
            if (a.starred) const Positioned(top: 4, right: 4, child: Icon(Icons.star, size: 16, color: Colors.amber)),
          ],
        ),
      ),
    );
  }

  Widget _row(Article a) {
    return ListTile(
      onTap: () => _open(a),
      onLongPress: () => newsService.toggleStar(a),
      leading: SizedBox(
        width: 72,
        height: 56,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: a.image != null
              ? CachedNetworkImage(imageUrl: a.image!, fit: BoxFit.cover, errorWidget: (c, u, e) => _placeholder())
              : _placeholder(),
        ),
      ),
      title: Text(a.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: a.read ? FontWeight.w400 : FontWeight.w700)),
      subtitle: Text('${a.feedTitle} • ${timeAgo(a.published)}', style: const TextStyle(fontSize: 11)),
      trailing: a.starred ? const Icon(Icons.star, color: Colors.amber, size: 18) : null,
    );
  }

  Widget _body(List<Article> list) {
    if (list.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 140),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                newsService.refreshing ? 'در حال دریافت...' : 'خبری برای نمایش نیست.\nبرای به‌روزرسانی صفحه را به پایین بکشید.',
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      );
    }
    if (newsService.layout == LayoutMode.list) {
      return ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: list.length,
        itemBuilder: (c, i) => _row(list[i]),
      );
    }
    final cols = newsService.layout == LayoutMode.grid3 ? 3 : 2;
    return GridView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(4),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: cols, childAspectRatio: 0.78, mainAxisSpacing: 4, crossAxisSpacing: 4),
      itemCount: list.length,
      itemBuilder: (c, i) => _tile(list[i]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: newsService,
      builder: (context, _) {
        final list = _visible();
        return Scaffold(
          drawer: _drawer(context),
          appBar: AppBar(
            title: _searching
                ? TextField(
                    autofocus: true,
                    onChanged: (v) => setState(() => _q = v),
                    decoration: const InputDecoration(hintText: 'جست‌وجو...', border: InputBorder.none),
                  )
                : Text(_title(list.length), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            actions: [
              IconButton(
                icon: Icon(_searching ? Icons.close : Icons.search),
                onPressed: () => setState(() {
                  _searching = !_searching;
                  if (!_searching) _q = '';
                }),
              ),
              PopupMenuButton<String>(
                onSelected: _menu,
                itemBuilder: (c) => [
                  PopupMenuItem(value: 'hide', child: Text(newsService.hideRead ? 'نمایش خوانده‌شده‌ها' : 'پنهان‌کردن خوانده‌شده‌ها')),
                  const PopupMenuItem(value: 'markall', child: Text('همه را خوانده‌شده کن')),
                  const PopupMenuItem(value: 'delall', child: Text('حذف همه')),
                  const PopupMenuItem(value: 'delread', child: Text('حذف خوانده‌شده‌ها')),
                  const PopupMenuItem(value: 'sort', child: Text('مرتب‌سازی')),
                  const PopupMenuItem(value: 'layout', child: Text('تغییر چیدمان')),
                ],
              ),
            ],
          ),
          body: Column(
            children: [
              SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                      child: ChoiceChip(label: const Text('همه'), selected: _cat == null, onSelected: (_) => setState(() => _cat = null)),
                    ),
                    for (final c in newsService.categories)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                        child: ChoiceChip(label: Text(c), selected: _cat == c, onSelected: (_) => setState(() => _cat = c)),
                      ),
                  ],
                ),
              ),
              if (newsService.refreshing) const LinearProgressIndicator(minHeight: 2),
              Expanded(child: RefreshIndicator(onRefresh: _refresh, child: _body(list))),
              if (newsService.lastUpdate != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Text('آخرین به‌روزرسانی: ${timeAgo(newsService.lastUpdate!)}', style: const TextStyle(fontSize: 10, color: Colors.white38)),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _drawer(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    Widget item(IconData icon, String label, {int? count, bool selected = false, required VoidCallback onTap}) {
      return ListTile(
        dense: true,
        selected: selected,
        leading: Icon(icon, size: 20),
        title: Text(label),
        trailing: count == null ? null : Text('$count', style: TextStyle(color: primary, fontWeight: FontWeight.w800)),
        onTap: () {
          Navigator.pop(context);
          onTap();
        },
      );
    }

    return Drawer(
      child: SafeArea(
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(18),
              child: Text('mustang720', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: primary, letterSpacing: 1)),
            ),
            item(Icons.schedule, '۲۴ ساعت گذشته', count: newsService.last24, selected: _kind == 'last24', onTap: () => setState(() { _kind = 'last24'; _feedId = null; })),
            item(Icons.mark_email_unread_outlined, 'تمام خوانده‌نشده‌ها', count: newsService.unread, selected: _kind == 'unread', onTap: () => setState(() { _kind = 'unread'; _feedId = null; })),
            item(Icons.star_outline, 'ستاره‌دارها (آرشیو ذخیره‌شده)', count: newsService.starredCount, selected: _kind == 'starred', onTap: () => setState(() { _kind = 'starred'; _feedId = null; })),
            item(Icons.all_inbox_outlined, 'همهٔ اخبار', selected: _kind == 'all', onTap: () => setState(() { _kind = 'all'; _feedId = null; })),
            const Divider(),
            const Padding(padding: EdgeInsets.fromLTRB(16, 4, 16, 4), child: Text('منابع خبری', style: TextStyle(fontSize: 12, color: Colors.white54))),
            for (final f in newsService.feeds)
              item(Icons.rss_feed, f.title, count: newsService.unreadFor(f.id), selected: _kind == 'feed' && _feedId == f.id, onTap: () => setState(() { _kind = 'feed'; _feedId = f.id; })),
            const Divider(),
            item(Icons.telegram, 'کانال‌های تلگرام', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TelegramPage()))),
            item(Icons.camera_alt_outlined, 'استوری اینستاگرام', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramPage()))),
            item(Icons.tune, 'مدیریت منابع دلخواه', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage()))),
            const Divider(),
            item(Icons.sync, 'همین الان به‌روزرسانی کن', onTap: _refresh),
            item(Icons.palette_outlined, 'تغییر پوسته', onTap: () => _themeSheet(context)),
            item(Icons.settings_outlined, 'تنظیمات', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage()))),
            item(Icons.info_outline, 'دربارهٔ برنامه', onTap: () => showAboutDialog(context: context, applicationName: 'mustang720', applicationVersion: '0.1.0')),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                // نیازمند سرویس آماری سمت سرور؛ بدون سرور «نامشخص»
                'کاربران آنلاین: نامشخص',
                style: const TextStyle(fontSize: 11, color: Colors.white38),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _themeSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            for (final s in kThemeSpecs)
              ListTile(
                leading: CircleAvatar(backgroundColor: s.accent, radius: 10),
                title: Text(s.name),
                trailing: themeController.spec.id == s.id ? const Icon(Icons.check) : null,
                onTap: () {
                  themeController.select(s);
                  Navigator.pop(ctx);
                },
              ),
          ],
        ),
      ),
    );
  }
}
