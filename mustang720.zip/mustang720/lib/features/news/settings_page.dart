import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/store.dart';
import '../connect/proxy_service.dart';
import 'news_models.dart';
import 'news_service.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Future<String?> _ask(BuildContext context, String title, {String hint = ''}) {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, textDirection: TextDirection.ltr, decoration: InputDecoration(hintText: hint)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('افزودن')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات')),
      body: ListenableBuilder(
        listenable: Listenable.merge([newsService, proxyService, themeController]),
        builder: (context, _) => ListView(
          padding: const EdgeInsets.all(12),
          children: [
            const Text('پوسته', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final s in kThemeSpecs)
                  ChoiceChip(
                    avatar: CircleAvatar(backgroundColor: s.accent, radius: 8),
                    label: Text(s.name),
                    selected: themeController.spec.id == s.id,
                    onSelected: (_) => themeController.select(s),
                  ),
              ],
            ),
            const Divider(height: 32),
            Row(
              children: [
                const Expanded(child: Text('منابع خبری (RSS)', style: TextStyle(fontWeight: FontWeight.w800))),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed: () async {
                    final url = await _ask(context, 'آدرس RSS', hint: 'https://example.com/feed');
                    if (url == null || url.isEmpty) return;
                    final uri = Uri.tryParse(url);
                    final title = uri?.host.replaceFirst('www.', '') ?? url;
                    await newsService.addFeed(Feed(url.hashCode.toString(), title, url, 'عمومی'));
                  },
                ),
              ],
            ),
            for (final f in newsService.feeds)
              ListTile(
                dense: true,
                title: Text('${f.title} • ${f.category}'),
                subtitle: Text(f.url, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 10)),
                trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => newsService.removeFeed(f)),
              ),
            const Divider(height: 32),
            Row(
              children: [
                const Expanded(child: Text('منابع پروکسی تلگرام', style: TextStyle(fontWeight: FontWeight.w800))),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed: () async {
                    final url = await _ask(context, 'آدرس فایل متنی/JSON (مثلاً raw گیت‌هاب)', hint: 'https://raw.githubusercontent.com/...');
                    if (url != null) await proxyService.addSource(url);
                  },
                ),
              ],
            ),
            if (proxyService.sources.isEmpty)
              const Padding(padding: EdgeInsets.all(8), child: Text('هنوز منبعی اضافه نشده. فایل باید شامل لینک‌هایی به شکل tg://proxy?server=…&port=…&secret=… یا t.me/proxy?… باشد.', style: TextStyle(fontSize: 12))),
            for (final s in proxyService.sources)
              ListTile(
                dense: true,
                title: Text(s, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 11)),
                trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => proxyService.removeSource(s)),
              ),
            const Divider(height: 32),
            ListTile(
              leading: const Icon(Icons.delete_sweep_outlined),
              title: const Text('پاک‌کردن کش اخبار'),
              onTap: () async {
                await newsService.deleteWhere((a) => true);
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('انجام شد')));
              },
            ),
            ListTile(
              leading: const Icon(Icons.restart_alt),
              title: const Text('بازنشانی رکوردها و سکه‌های بازی‌ها'),
              onTap: () async {
                for (final k in ['rec_hormoz', 'rec_shahed', 'coins', 'trivia_score', 'sudoku_wins', 'hormoz_best_level']) {
                  await Prefs.setInt(k, 0);
                }
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('انجام شد')));
              },
            ),
          ],
        ),
      ),
    );
  }
}
