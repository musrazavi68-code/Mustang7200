import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// ذخیرهٔ JSON در فایل داخلی برنامه (برای کش آفلاین اخبار و پیام‌ها)
class JsonStore {
  final String name;
  JsonStore(this.name);

  Future<File> _file() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$name');
  }

  Future<dynamic> read() async {
    try {
      final f = await _file();
      if (!await f.exists()) return null;
      return jsonDecode(await f.readAsString());
    } catch (_) {
      return null;
    }
  }

  Future<void> write(dynamic data) async {
    try {
      final f = await _file();
      await f.writeAsString(jsonEncode(data));
    } catch (_) {}
  }

  Future<void> delete() async {
    try {
      final f = await _file();
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}

/// میان‌بر SharedPreferences
class Prefs {
  static SharedPreferences? _sp;

  static Future<SharedPreferences> get _s async {
    _sp ??= await SharedPreferences.getInstance();
    return _sp!;
  }

  static Future<int> getInt(String k, [int d = 0]) async => (await _s).getInt(k) ?? d;
  static Future<void> setInt(String k, int v) async {
    await (await _s).setInt(k, v);
  }

  static Future<bool> getBool(String k, [bool d = false]) async => (await _s).getBool(k) ?? d;
  static Future<void> setBool(String k, bool v) async {
    await (await _s).setBool(k, v);
  }

  static Future<String?> getString(String k) async => (await _s).getString(k);
  static Future<void> setString(String k, String v) async {
    await (await _s).setString(k, v);
  }

  static Future<List<String>?> getList(String k) async => (await _s).getStringList(k);
  static Future<void> setList(String k, List<String> v) async {
    await (await _s).setStringList(k, v);
  }
}
