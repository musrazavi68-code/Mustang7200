import 'package:flutter/material.dart';
import 'store.dart';

class AppThemeSpec {
  final String id;
  final String name;
  final Brightness brightness;
  final Color bg;
  final Color surface;
  final Color accent;
  final Color onBg;
  const AppThemeSpec(this.id, this.name, this.brightness, this.bg, this.surface, this.accent, this.onBg);
}

const kThemeSpecs = <AppThemeSpec>[
  AppThemeSpec('minimal', 'مینیمال', Brightness.dark, Color(0xFF101114), Color(0xFF1B1D22), Color(0xFF39FF88), Color(0xFFECEDEF)),
  AppThemeSpec('glass', 'شیشه‌ای', Brightness.dark, Color(0xFF0B1220), Color(0xFF16233A), Color(0xFF7DD3FC), Color(0xFFE8F1FA)),
  AppThemeSpec('liquid', 'Liquid Glass', Brightness.dark, Color(0xFF0A0F1F), Color(0xFF1A2540), Color(0xFF8B9BFF), Color(0xFFEAEDFF)),
  AppThemeSpec('neon', 'Dark Neon', Brightness.dark, Color(0xFF05060A), Color(0xFF10121A), Color(0xFF00FF9C), Color(0xFFE6FFF5)),
  AppThemeSpec('industrial', 'صنعتی', Brightness.dark, Color(0xFF2B2D2F), Color(0xFF3A3D40), Color(0xFF9BE15D), Color(0xFFE9EAEA)),
  AppThemeSpec('pastel', 'پاستیلی', Brightness.light, Color(0xFFFAF7F2), Color(0xFFFFFFFF), Color(0xFFE57C93), Color(0xFF2D2A32)),
];

final themeController = ThemeController();

class ThemeController extends ChangeNotifier {
  AppThemeSpec spec = kThemeSpecs.first;

  Future<void> load() async {
    final id = await Prefs.getString('theme');
    for (final s in kThemeSpecs) {
      if (s.id == id) spec = s;
    }
  }

  Future<void> select(AppThemeSpec s) async {
    spec = s;
    notifyListeners();
    await Prefs.setString('theme', s.id);
  }

  ThemeData get themeData {
    final scheme = ColorScheme.fromSeed(seedColor: spec.accent, brightness: spec.brightness)
        .copyWith(primary: spec.accent, surface: spec.surface);
    final base = ThemeData(useMaterial3: true, brightness: spec.brightness, colorScheme: scheme);
    return base.copyWith(
      scaffoldBackgroundColor: spec.bg,
      appBarTheme: AppBarTheme(backgroundColor: spec.bg, foregroundColor: spec.onBg, elevation: 0),
      drawerTheme: DrawerThemeData(backgroundColor: spec.bg),
      dialogTheme: DialogThemeData(backgroundColor: spec.surface),
      textTheme: base.textTheme.apply(bodyColor: spec.onBg, displayColor: spec.onBg),
    );
  }
}
